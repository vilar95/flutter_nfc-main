const String githubApiKey = "<sua_chave_aqui>";
